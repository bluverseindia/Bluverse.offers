import { notFound, redirect } from 'next/navigation';
import Image from 'next/image';
import Header from '@/components/Header';
import { supabaseAdmin } from '@/lib/supabase-server';
import { Product, Settings } from '@/lib/types';
import { computeTotal, buildWhatsAppMessage, buildWhatsAppLink } from '@/lib/pricing';

export const revalidate = 0;

export default async function CheckoutPage({
  searchParams
}: {
  searchParams: { p1?: string; s1?: string; p2?: string; s2?: string };
}) {
  const { p1, s1, p2, s2 } = searchParams;
  if (!p1 || !s1 || !p2 || !s2) redirect('/products?picking=1');

  const supabase = supabaseAdmin();
  const [{ data: prod1 }, { data: prod2 }, { data: settingsRow }] = await Promise.all([
    supabase.from('products').select('*').eq('slug', p1).single(),
    supabase.from('products').select('*').eq('slug', p2).single(),
    supabase.from('settings').select('*').eq('id', 1).single()
  ]);

  if (!prod1 || !prod2 || !settingsRow) notFound();

  const product1 = prod1 as Product;
  const product2 = prod2 as Product;
  const settings = settingsRow as Settings;

  const { base, extra1, extra2, shipping, grandTotal } = computeTotal(product1, product2, settings);
  const message = buildWhatsAppMessage({ p1: product1, p1Size: s1, p2: product2, p2Size: s2, settings });
  const waLink = buildWhatsAppLink(settings.whatsapp_number, message);

  return (
    <main className="min-h-screen bg-paper">
      <Header step="Step 3 — Price Breakdown" />
      <div className="mx-auto max-w-2xl px-5 py-10">
        <h1 className="font-display text-4xl tracking-wide sm:text-5xl">Your Offer</h1>

        <div className="mt-8 space-y-4">
          {[{ p: product1, size: s1 }, { p: product2, size: s2 }].map(({ p, size }, i) => (
            <div key={p.id + i} className="flex items-center gap-4 rounded-3xl border border-ink/10 bg-bone p-4">
              <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl bg-white">
                {p.images?.[0] && <Image src={p.images[0]} alt={p.name} fill className="object-cover" />}
              </div>
              <div>
                <p className="text-xs uppercase tracking-widest2 text-smoke">Pair {i + 1}</p>
                <h3 className="font-display text-xl tracking-wide">{p.name}</h3>
                <p className="text-xs text-ink/60">Size UK {size} · {p.extra_price > 0 ? `+₹${p.extra_price} extra` : 'No extra charge'}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-3xl border border-ink/10 p-6">
          <Row label="Base Price" value={base} />
          <Row label="Extra Charge — Pair 1" value={extra1} />
          <Row label="Extra Charge — Pair 2" value={extra2} />
          <Row label="Shipping" value={shipping} />
          <div className="mt-4 flex items-center justify-between border-t border-ink/10 pt-4">
            <span className="font-display text-2xl tracking-wide">Grand Total</span>
            <span className="font-display text-3xl tracking-wide">₹{grandTotal}</span>
          </div>
        </div>

        <a
          href={waLink}
          target="_blank"
          rel="noopener noreferrer"
          className="focus-ring mt-8 flex w-full items-center justify-center gap-2 rounded-full bg-[#111] py-5 text-sm font-semibold uppercase tracking-wide text-paper transition hover:opacity-90"
        >
          Order via WhatsApp →
        </a>
        <p className="mt-3 text-center text-xs text-smoke">
          You'll be redirected to WhatsApp with your order summary pre-filled.
        </p>
      </div>
    </main>
  );
}

function Row({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center justify-between py-2 text-sm">
      <span className="text-ink/70">{label}</span>
      <span className="font-semibold">₹{value}</span>
    </div>
  );
}
