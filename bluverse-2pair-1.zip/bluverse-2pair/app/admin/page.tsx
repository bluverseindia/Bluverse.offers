import { supabaseAdmin } from '@/lib/supabase-server';
import { Product, Settings } from '@/lib/types';
import AdminDashboard from './AdminDashboard';

export const revalidate = 0;

export default async function AdminPage() {
  const supabase = supabaseAdmin();
  const [{ data: products }, { data: settings }] = await Promise.all([
    supabase.from('products').select('*').order('created_at', { ascending: false }),
    supabase.from('settings').select('*').eq('id', 1).single()
  ]);

  return (
    <AdminDashboard
      initialProducts={(products ?? []) as Product[]}
      initialSettings={settings as Settings}
    />
  );
}
