import { MetadataRoute } from 'next';
import { supabaseAdmin } from '@/lib/supabase-server';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_SITE_URL || 'https://bluverse.example.com';
  const supabase = supabaseAdmin();
  const { data } = await supabase.from('products').select('slug, created_at');

  const productUrls = (data ?? []).map((p) => ({
    url: `${base}/products/${p.slug}`,
    lastModified: p.created_at
  }));

  return [
    { url: base, lastModified: new Date() },
    { url: `${base}/products`, lastModified: new Date() },
    ...productUrls
  ];
}
