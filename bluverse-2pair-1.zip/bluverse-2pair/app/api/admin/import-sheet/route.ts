import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase-server';
import { requireAdmin } from '@/lib/require-admin';

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"' && text[i + 1] === '"') {
        field += '"';
        i++;
      } else if (c === '"') {
        inQuotes = false;
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      row.push(field);
      field = '';
    } else if (c === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else if (c !== '\r') {
      field += c;
    }
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

function driveIdFromUrl(url: string): string | null {
  const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/) || url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  return match ? match[1] : null;
}

function toDriveImageUrl(url: string): string | null {
  const id = driveIdFromUrl(url);
  if (!id) return null;
  return `https://drive.google.com/thumbnail?id=${id}&sz=w1000`;
}

export async function POST() {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const sheetId = process.env.GOOGLE_SHEET_ID;
  if (!sheetId) return NextResponse.json({ error: 'GOOGLE_SHEET_ID is not set.' }, { status: 400 });

  const csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`;
  const csvRes = await fetch(csvUrl, { cache: 'no-store' });
  if (!csvRes.ok) {
    return NextResponse.json({ error: 'Could not fetch sheet. Make sure it is shared as "Anyone with the link — Viewer".' }, { status: 400 });
  }
  const csvText = await csvRes.text();
  const rows = parseCsv(csvText);

  // Row 0 = header: Shoe name, Extra price, size, image, image 2
  type Group = { name: string; extraPrice: number; size: string; images: string[] };
  const groups = new Map<string, Group>();

  for (let i = 1; i < rows.length; i++) {
    const [rawName, rawPrice, rawSize, rawImg1, rawImg2] = rows[i];
    const name = (rawName || '').trim();
    if (!name) continue;

    const extraPrice = Number((rawPrice || '0').trim()) || 0;
    const size = (rawSize || '').trim();
    const key = `${name.toLowerCase()}::${extraPrice}`;

    if (!groups.has(key)) {
      groups.set(key, { name, extraPrice, size, images: [] });
    }
    const g = groups.get(key)!;

    for (const raw of [rawImg1, rawImg2]) {
      if (!raw || !raw.trim()) continue;
      const img = toDriveImageUrl(raw.trim());
      if (img && !g.images.includes(img)) g.images.push(img);
    }
  }

  const supabase = supabaseAdmin();
  let count = 0;

  for (const g of groups.values()) {
    const slug = slugify(g.extraPrice > 0 ? `${g.name}-${g.extraPrice}` : g.name);
    const sizes = g.size
      .replace(/uk/i, '')
      .split('-')
      .map((s) => s.trim())
      .filter(Boolean);

    const { data: existing } = await supabase.from('products').select('id').eq('slug', slug).maybeSingle();
    if (existing) continue;

    const { error } = await supabase.from('products').insert({
      name: g.name,
      slug,
      description: null,
      category: null,
      extra_price: g.extraPrice,
      sizes,
      images: g.images,
      in_stock: true
    });

    if (!error) count++;
  }

  return NextResponse.json({ ok: true, count });
}
