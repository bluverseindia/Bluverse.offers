import Link from 'next/link';
import Header from '@/components/Header';
import Marquee from '@/components/Marquee';

export default function Home() {
  return (
    <main className="min-h-screen bg-paper">
      <Header />

      <section className="mx-auto max-w-6xl px-5 pb-16 pt-14 sm:pt-24">
        <p className="animate-fade text-xs font-semibold uppercase tracking-widest2 text-smoke">
          The Bluverse Offer
        </p>
        <h1 className="animate-rise mt-4 font-display text-[15vw] leading-[0.85] tracking-tight sm:text-[9rem]">
          BUY 2
          <br />
          WEAR MORE
        </h1>
        <p className="animate-rise mt-6 max-w-md text-base text-ink/70" style={{ animationDelay: '0.1s' }}>
          Choose any two pairs from the collection. One simple checkout. Ordered straight to WhatsApp — no cart, no clutter.
        </p>
        <Link
          href="/products?picking=1"
          className="animate-rise mt-8 inline-flex items-center gap-3 rounded-full bg-ink px-8 py-4 text-sm font-semibold uppercase tracking-wide text-paper transition hover:opacity-85"
          style={{ animationDelay: '0.2s' }}
        >
          Start Your Pair Selection →
        </Link>
      </section>

      <Marquee />

      <section className="mx-auto max-w-6xl px-5 py-16">
        <div className="grid gap-8 sm:grid-cols-3">
          {[
            { n: '01', t: 'Pick Pair One', d: 'Browse the full collection and choose your first pair, then select your size.' },
            { n: '02', t: 'Pick Pair Two', d: 'Choose your second pair in any combination you like — mix brands, mix styles.' },
            { n: '03', t: 'Order on WhatsApp', d: 'See your full price breakdown, then send your order straight to us in one tap.' }
          ].map((s) => (
            <div key={s.n} className="rounded-3xl border border-ink/10 bg-bone p-6">
              <span className="font-display text-4xl text-smoke">{s.n}</span>
              <h3 className="mt-3 font-display text-2xl tracking-wide">{s.t}</h3>
              <p className="mt-2 text-sm text-ink/70">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-ink/10 px-5 py-8 text-center text-xs uppercase tracking-widest2 text-smoke">
        © {new Date().getFullYear()} Bluverse
      </footer>
    </main>
  );
}
