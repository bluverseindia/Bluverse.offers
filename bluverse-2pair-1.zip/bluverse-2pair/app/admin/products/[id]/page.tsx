import { supabaseAdmin } from '@/lib/supabase-server';
import { Product } from '@/lib/types';
import ProductForm from './ProductForm';

export const revalidate = 0;

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const isNew = params.id === 'new';
  let product: Product | null = null;

  if (!isNew) {
    const supabase = supabaseAdmin();
    const { data } = await supabase.from('products').select('*').eq('id', params.id).single();
    product = data as Product;
  }

  return (
    <main className="min-h-screen bg-paper px-5 py-10">
      <div className="mx-auto max-w-2xl">
        <h1 className="font-display text-3xl tracking-wide">{isNew ? 'Add Product' : 'Edit Product'}</h1>
        <ProductForm product={product} />
      </div>
    </main>
  );
}
