'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Product, Settings } from '@/lib/types';
import { supabaseBrowser } from '@/lib/supabase-browser';

export default function AdminDashboard({
  initialProducts,
  initialSettings
}: {
  initialProducts: Product[];
  initialSettings: Settings;
}) {
  const router = useRouter();
  const [products, setProducts] = useState(initialProducts);
  const [query, setQuery] = useState('');
  const [settings, setSettings] = useState(initialSettings);
  const [importing, setImporting] = useState(false);
  const [importMsg, setImportMsg] = useState<string | null>(null);
  const [savingSettings, setSavingSettings] = useState(false);

  const filtered = products.filter((p) => p.name.toLowerCase().includes(query.toLowerCase()));

  async function toggleStock(p: Product) {
    const res = await fetch(`/api/admin/products/${p.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ in_stock: !p.in_stock })
    });
    if (res.ok) {
      setProducts((prev) => prev.map((x) => (x.id === p.id ? { ...x, in_stock: !x.in_stock } : x)));
    }
  }

  async function deleteProduct(id: string) {
    if (!confirm('Delete this product permanently?')) return;
    const res = await fetch(`/api/admin/products/${id}`, { method: 'DELETE' });
    if (res.ok) setProducts((prev) => prev.filter((p) => p.id !== id));
  }

  async function runImport() {
    setImporting(true);
    setImportMsg(null);
    const res = await fetch('/api/admin/import-sheet', { method: 'POST' });
    const json = await res.json();
    setImporting(false);
    if (res.ok) {
      setImportMsg(`Imported ${json.count} products.`);
      router.refresh();
    } else {
      setImportMsg(json.error || 'Import failed.');
    }
  }

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    setSavingSettings(true);
    await fetch('/api/admin/settings', { method: 'PATCH', body: JSON.stringify(settings) });
    setSavingSettings(false);
  }

  async function logout() {
    const supabase = supabaseBrowser();
    await supabase.auth.signOut();
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <main className="min-h-screen bg-paper">
      <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/90 px-5 py-4 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between">
          <h1 className="font-display text-2xl tracking-wide">BLUVERSE ADMIN</h1>
          <button onClick={logout} className="text-xs font-semibold uppercase tracking-wide text-smoke hover:text-ink">
            Log Out
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-8">
        {/* Settings */}
        <section className="rounded-3xl border border-ink/10 bg-bone p-6">
          <h2 className="font-display text-2xl tracking-wide">Offer Settings</h2>
          <form onSubmit={saveSettings} className="mt-4 grid gap-4 sm:grid-cols-4">
            <Field label="Base Price (₹)">
              <input
                type="number"
                value={settings.base_price}
                onChange={(e) => setSettings({ ...settings, base_price: Number(e.target.value) })}
                className="focus-ring w-full rounded-xl border border-ink/15 px-3 py-2 text-sm"
              />
            </Field>
            <Field label="Shipping (₹)">
              <input
                type="number"
                value={settings.shipping_charge}
                onChange={(e) => setSettings({ ...settings, shipping_charge: Number(e.target.value) })}
                className="focus-ring w-full rounded-xl border border-ink/15 px-3 py-2 text-sm"
              />
            </Field>
            <Field label="WhatsApp Number">
              <input
                type="text"
                value={settings.whatsapp_number}
                onChange={(e) => setSettings({ ...settings, whatsapp_number: e.target.value })}
                className="focus-ring w-full rounded-xl border border-ink/15 px-3 py-2 text-sm"
              />
            </Field>
            <div className="flex items-end">
              <button
                type="submit"
                disabled={savingSettings}
                className="focus-ring w-full rounded-full bg-ink py-2.5 text-xs font-semibold uppercase tracking-wide text-paper disabled:opacity-50"
              >
                {savingSettings ? 'Saving…' : 'Save Settings'}
              </button>
            </div>
          </form>
        </section>

        {/* Import */}
        <section className="mt-6 rounded-3xl border border-ink/10 p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl tracking-wide">Import from Google Sheet</h2>
              <p className="text-xs text-smoke">One-time bulk import. Existing products with the same name + price will be skipped.</p>
            </div>
            <button
              onClick={runImport}
              disabled={importing}
              className="focus-ring rounded-full border border-ink px-6 py-3 text-xs font-semibold uppercase tracking-wide hover:bg-ink hover:text-paper disabled:opacity-50"
            >
              {importing ? 'Importing…' : 'Run Import'}
            </button>
          </div>
          {importMsg && <p className="mt-3 text-xs">{importMsg}</p>}
        </section>

        {/* Products */}
        <section className="mt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-2xl tracking-wide">Products ({products.length})</h2>
            <div className="flex gap-2">
              <input
                placeholder="Search…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="focus-ring rounded-full border border-ink/15 px-4 py-2 text-sm"
              />
              <Link
                href="/admin/products/new"
                className="focus-ring rounded-full bg-ink px-4 py-2 text-xs font-semibold uppercase tracking-wide text-paper"
              >
                + Add Product
              </Link>
            </div>
          </div>

          <div className="mt-4 grid gap-3">
            {filtered.map((p) => (
              <div key={p.id} className="flex items-center gap-4 rounded-2xl border border-ink/10 bg-white p-3">
                <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-bone">
                  {p.images?.[0] && <Image src={p.images[0]} alt={p.name} fill className="object-cover" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{p.name}</p>
                  <p className="text-xs text-smoke">
                    ₹{p.extra_price} extra · Sizes {p.sizes.join(', ')} · {p.in_stock ? 'In stock' : 'Out of stock'}
                  </p>
                </div>
                <button
                  onClick={() => toggleStock(p)}
                  className={`focus-ring rounded-full px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wide ${
                    p.in_stock ? 'bg-bone text-ink' : 'bg-ink text-paper'
                  }`}
                >
                  {p.in_stock ? 'Mark Out of Stock' : 'Mark Available'}
                </button>
                <Link
                  href={`/admin/products/${p.id}`}
                  className="focus-ring rounded-full border border-ink/20 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wide"
                >
                  Edit
                </Link>
                <button
                  onClick={() => deleteProduct(p.id)}
                  className="focus-ring rounded-full border border-red-300 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wide text-red-600"
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[10px] font-semibold uppercase tracking-widest2 text-smoke">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
