/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0a0a0a',
        paper: '#f7f6f3',
        bone: '#eeece6',
        line: '#242424',
        smoke: '#8a8a86'
      },
      fontFamily: {
        display: ['var(--font-display)'],
        body: ['var(--font-body)']
      },
      letterSpacing: {
        widest2: '0.28em'
      },
      keyframes: {
        rise: { '0%': { opacity: 0, transform: 'translateY(16px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } },
        fade: { '0%': { opacity: 0 }, '100%': { opacity: 1 } }
      },
      animation: {
        rise: 'rise .6s cubic-bezier(.16,1,.3,1) both',
        fade: 'fade .5s ease both'
      }
    }
  },
  plugins: []
};
