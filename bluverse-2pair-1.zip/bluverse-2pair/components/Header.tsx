import Link from 'next/link';

export default function Header({ step }: { step?: string }) {
  return (
    <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link href="/" className="font-display text-2xl tracking-wide">
          BLUVERSE
        </Link>
        {step && (
          <span className="hidden text-xs uppercase tracking-widest2 text-smoke sm:block">{step}</span>
        )}
        <Link
          href="/products"
          className="rounded-full border border-ink px-4 py-2 text-xs font-semibold uppercase tracking-wide transition hover:bg-ink hover:text-paper"
        >
          Shop Offer
        </Link>
      </div>
    </header>
  );
}
