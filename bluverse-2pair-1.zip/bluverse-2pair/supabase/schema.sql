-- Run this entire file once in Supabase: Dashboard > SQL Editor > New query > paste > Run

create extension if not exists "pgcrypto";

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  category text,
  extra_price numeric not null default 0,
  sizes text[] not null default '{}',
  images text[] not null default '{}',
  in_stock boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists settings (
  id int primary key,
  base_price numeric not null default 999,
  shipping_charge numeric not null default 99,
  whatsapp_number text not null default '919946296220'
);

insert into settings (id, base_price, shipping_charge, whatsapp_number)
values (1, 999, 99, '919946296220')
on conflict (id) do nothing;

-- Row Level Security: public can read, only authenticated (admin) users can write
alter table products enable row level security;
alter table settings enable row level security;

create policy "Public read products" on products for select using (true);
create policy "Public read settings" on settings for select using (true);

create policy "Admin write products" on products for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

create policy "Admin write settings" on settings for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- Storage bucket for product photos uploaded from the Admin Panel
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

create policy "Public read product images" on storage.objects for select
  using (bucket_id = 'product-images');

create policy "Admin upload product images" on storage.objects for insert
  with check (bucket_id = 'product-images' and auth.role() = 'authenticated');

create policy "Admin delete product images" on storage.objects for delete
  using (bucket_id = 'product-images' and auth.role() = 'authenticated');
