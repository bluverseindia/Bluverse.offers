'use client';

import { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { Product } from '@/lib/types';

export default function ProductDetailClient({
  product,
  picking,
  p1,
  s1
}: {
  product: Product;
  picking: string;
  p1?: string;
  s1?: string;
}) {
  const router = useRouter();
  const [activeImg, setActiveImg] = useState(0);
  const [size, setSize] = useState<string | null>(null);
  const outOfStock = !product.in_stock;

  function handleContinue() {
    if (!size || outOfStock) return;

    if (picking === '1') {
      const params = new URLSearchParams({ picking: '2', p1: product.slug, s1: size });
      router.push(`/products?${params.toString()}`);
    } else {
      if (!p1 || !s1) {
        router.push('/products?picking=1');
        return;
      }
      const params = new URLSearchParams({ p1, s1, p2: product.slug, s2: size });
      router.push(`/checkout?${params.toString()}`);
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <div className="grid gap-10 sm:grid-cols-2">
        <div>
          <div className="relative aspect-square w-full overflow-hidden rounded-3xl bg-white">
            {product.images?.[activeImg] ? (
              <Image
                src={product.images[activeImg]}
                alt={product.name}
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
                priority
              />
            ) : (
              <div className="flex h-full items-center justify-center text-smoke">No image</div>
            )}
            {outOfStock && (
              <span className="absolute left-4 top-4 rounded-full bg-ink px-3 py-1 text-[10px] font-semibold uppercase tracking-widest2 text-paper">
                Out of Stock
              </span>
            )}
          </div>
          {product.images?.length > 1 && (
            <div className="mt-3 flex gap-2 overflow-x-auto">
              {product.images.map((img, i) => (
                <button
                  key={img + i}
                  onClick={() => setActiveImg(i)}
                  className={`focus-ring relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border-2 ${
                    activeImg === i ? 'border-ink' : 'border-transparent'
                  }`}
                >
                  <Image src={img} alt="" fill className="object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <h1 className="font-display text-4xl tracking-wide sm:text-5xl">{product.name}</h1>
          <p className="mt-2 text-sm uppercase tracking-widest2 text-smoke">
            {product.extra_price > 0 ? `+ ₹${product.extra_price} extra charge` : 'No extra charge'}
          </p>
          {product.description && <p className="mt-5 text-sm leading-relaxed text-ink/70">{product.description}</p>}

          <div className="mt-8">
            <p className="text-xs font-semibold uppercase tracking-widest2 text-ink">Select size (UK)</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  disabled={outOfStock}
                  onClick={() => setSize(s)}
                  className={`focus-ring h-12 w-12 rounded-full border text-sm font-semibold transition ${
                    size === s ? 'border-ink bg-ink text-paper' : 'border-ink/20 hover:border-ink'
                  } ${outOfStock ? 'cursor-not-allowed opacity-40' : ''}`}
                >
                  {s}
                </button>
              ))}
            </div>
            {!size && !outOfStock && <p className="mt-2 text-xs text-smoke">Choose a size to continue.</p>}
          </div>

          <button
            onClick={handleContinue}
            disabled={!size || outOfStock}
            className="focus-ring mt-8 w-full rounded-full bg-ink py-4 text-sm font-semibold uppercase tracking-wide text-paper transition disabled:cursor-not-allowed disabled:opacity-30 sm:w-auto sm:px-10"
          >
            {outOfStock ? 'Out of Stock' : picking === '1' ? 'Continue to Pair 2 →' : 'Continue to Price →'}
          </button>
        </div>
      </div>
    </div>
  );
}
