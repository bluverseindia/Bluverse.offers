import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase-server';
import { requireAdmin } from '@/lib/require-admin';

export async function PATCH(req: Request) {
  if (!(await requireAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const supabase = supabaseAdmin();
  const { error } = await supabase
    .from('settings')
    .update({
      base_price: body.base_price,
      shipping_charge: body.shipping_charge,
      whatsapp_number: body.whatsapp_number
    })
    .eq('id', 1);

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
