import { notFound } from 'next/navigation';
import Header from '@/components/Header';
import { supabaseAdmin } from '@/lib/supabase-server';
import { Product } from '@/lib/types';
import ProductDetailClient from './ProductDetailClient';

export const revalidate = 0;

export default async function ProductDetailPage({
  params,
  searchParams
}: {
  params: { slug: string };
  searchParams: { picking?: string; p1?: string; s1?: string };
}) {
  const supabase = supabaseAdmin();
  const { data } = await supabase.from('products').select('*').eq('slug', params.slug).single();

  if (!data) notFound();

  const product = data as Product;
  const picking = searchParams.picking === '2' ? '2' : '1';

  return (
    <main className="min-h-screen bg-paper">
      <Header step={picking === '1' ? 'Step 1 — Select Pair 1' : 'Step 2 — Select Pair 2'} />
      <ProductDetailClient product={product} picking={picking} p1={searchParams.p1} s1={searchParams.s1} />
    </main>
  );
}
