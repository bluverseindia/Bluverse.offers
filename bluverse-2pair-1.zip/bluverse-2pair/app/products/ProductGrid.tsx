'use client';

import { useMemo, useState } from 'react';
import { Product } from '@/lib/types';
import ProductCard from '@/components/ProductCard';

type Filter = 'all' | 'no-extra' | 'extra';

export default function ProductGrid({
  products,
  picking,
  p1,
  s1
}: {
  products: Product[];
  picking: string;
  p1?: string;
  s1?: string;
}) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesQuery = p.name.toLowerCase().includes(query.trim().toLowerCase());
      const matchesFilter =
        filter === 'all' ? true : filter === 'no-extra' ? p.extra_price === 0 : p.extra_price > 0;
      return matchesQuery && matchesFilter;
    });
  }, [products, query, filter]);

  function hrefFor(slug: string) {
    const params = new URLSearchParams();
    params.set('picking', picking);
    if (picking === '2' && p1) params.set('p1', p1);
    if (picking === '2' && s1) params.set('s1', s1);
    return `/products/${slug}?${params.toString()}`;
  }

  return (
    <div>
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search shoes…"
          className="focus-ring w-full rounded-full border border-ink/15 bg-white px-5 py-3 text-sm sm:max-w-xs"
        />
        <div className="flex gap-2">
          {(['all', 'no-extra', 'extra'] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`focus-ring rounded-full border px-4 py-2 text-xs font-semibold uppercase tracking-wide transition ${
                filter === f ? 'border-ink bg-ink text-paper' : 'border-ink/15 text-ink/70 hover:border-ink'
              }`}
            >
              {f === 'all' ? 'All' : f === 'no-extra' ? '₹0 Extra' : 'Extra Charge'}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <p className="mt-16 text-center text-sm text-smoke">No shoes match your search.</p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} href={hrefFor(p.slug)} />
          ))}
        </div>
      )}
    </div>
  );
}
