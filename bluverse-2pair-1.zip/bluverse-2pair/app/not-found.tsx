import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-paper px-5 text-center">
      <h1 className="font-display text-6xl tracking-wide">404</h1>
      <p className="mt-2 text-sm text-smoke">That page doesn't exist.</p>
      <Link href="/" className="mt-6 rounded-full bg-ink px-6 py-3 text-xs font-semibold uppercase tracking-wide text-paper">
        Back Home
      </Link>
    </main>
  );
}
