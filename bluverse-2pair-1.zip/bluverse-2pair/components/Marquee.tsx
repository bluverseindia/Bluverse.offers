export default function Marquee({ text = 'PAIR ONE — PAIR TWO — ONE OFFER — ' }: { text?: string }) {
  const repeated = text.repeat(6);
  return (
    <div className="overflow-hidden border-y border-ink bg-ink py-3 text-paper">
      <div className="marquee-track font-display text-2xl tracking-wide">
        <span className="pr-4">{repeated}</span>
        <span className="pr-4" aria-hidden>{repeated}</span>
      </div>
    </div>
  );
}
