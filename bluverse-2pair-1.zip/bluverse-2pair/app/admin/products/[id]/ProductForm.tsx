'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Product } from '@/lib/types';
import { supabaseBrowser } from '@/lib/supabase-browser';

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

export default function ProductForm({ product }: { product: Product | null }) {
  const router = useRouter();
  const [name, setName] = useState(product?.name ?? '');
  const [description, setDescription] = useState(product?.description ?? '');
  const [category, setCategory] = useState(product?.category ?? '');
  const [extraPrice, setExtraPrice] = useState(product?.extra_price ?? 0);
  const [sizes, setSizes] = useState((product?.sizes ?? []).join(', '));
  const [images, setImages] = useState((product?.images ?? []).join('\n'));
  const [inStock, setInStock] = useState(product?.in_stock ?? true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFileUpload(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);
    setError(null);
    const supabase = supabaseBrowser();
    const uploadedUrls: string[] = [];

    for (const file of Array.from(files)) {
      const path = `${Date.now()}-${Math.random().toString(36).slice(2)}-${file.name.replace(/\s+/g, '-')}`;
      const { error: uploadError } = await supabase.storage.from('product-images').upload(path, file, {
        cacheControl: '31536000',
        upsert: false
      });
      if (uploadError) {
        setError(`Upload failed: ${uploadError.message}`);
        continue;
      }
      const { data } = supabase.storage.from('product-images').getPublicUrl(path);
      uploadedUrls.push(data.publicUrl);
    }

    if (uploadedUrls.length) {
      setImages((prev) => (prev ? `${prev}\n${uploadedUrls.join('\n')}` : uploadedUrls.join('\n')));
    }
    setUploading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = {
      name,
      slug: slugify(name),
      description,
      category,
      extra_price: Number(extraPrice),
      sizes: sizes.split(',').map((s) => s.trim()).filter(Boolean),
      images: images.split('\n').map((s) => s.trim()).filter(Boolean),
      in_stock: inStock
    };

    const url = product ? `/api/admin/products/${product.id}` : '/api/admin/products';
    const method = product ? 'PATCH' : 'POST';
    const res = await fetch(url, { method, body: JSON.stringify(payload) });

    setSaving(false);
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setError(j.error || 'Save failed.');
      return;
    }
    router.push('/admin');
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="mt-6 space-y-4">
      <Field label="Name">
        <input required value={name} onChange={(e) => setName(e.target.value)} className="input" />
      </Field>
      <Field label="Description">
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className="input" />
      </Field>
      <Field label="Category (optional)">
        <input value={category} onChange={(e) => setCategory(e.target.value)} className="input" />
      </Field>
      <Field label="Extra Charge (₹)">
        <input type="number" value={extraPrice} onChange={(e) => setExtraPrice(Number(e.target.value))} className="input" />
      </Field>
      <Field label="Sizes (comma separated, e.g. 6, 7, 8, 9, 10)">
        <input value={sizes} onChange={(e) => setSizes(e.target.value)} className="input" />
      </Field>
      <Field label="Upload photos">
        <input
          type="file"
          accept="image/*"
          multiple
          disabled={uploading}
          onChange={(e) => handleFileUpload(e.target.files)}
          className="input"
        />
        {uploading && <p className="mt-1 text-xs text-smoke">Uploading…</p>}
      </Field>
      <Field label="Image URLs (one per line — auto-filled by uploads above, or paste your own)">
        <textarea value={images} onChange={(e) => setImages(e.target.value)} rows={4} className="input" />
      </Field>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={inStock} onChange={(e) => setInStock(e.target.checked)} />
        In stock
      </label>

      {error && <p className="text-xs text-red-600">{error}</p>}

      <div className="flex gap-3 pt-2">
        <button disabled={saving} className="focus-ring rounded-full bg-ink px-6 py-3 text-xs font-semibold uppercase tracking-wide text-paper disabled:opacity-50">
          {saving ? 'Saving…' : 'Save Product'}
        </button>
        <button type="button" onClick={() => router.push('/admin')} className="focus-ring rounded-full border border-ink/20 px-6 py-3 text-xs font-semibold uppercase tracking-wide">
          Cancel
        </button>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgba(10, 10, 10, 0.15);
          padding: 0.65rem 0.9rem;
          font-size: 0.875rem;
        }
      `}</style>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[10px] font-semibold uppercase tracking-widest2 text-smoke">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
