import { Product, Settings } from './types';

export function computeTotal(p1: Product, p2: Product, settings: Settings) {
  const base = settings.base_price;
  const extra1 = p1.extra_price;
  const extra2 = p2.extra_price;
  const shipping = settings.shipping_charge;
  const grandTotal = base + extra1 + extra2 + shipping;
  return { base, extra1, extra2, shipping, grandTotal };
}

export function buildWhatsAppMessage(params: {
  p1: Product; p1Size: string;
  p2: Product; p2Size: string;
  settings: Settings;
}) {
  const { p1, p1Size, p2, p2Size, settings } = params;
  const { base, extra1, extra2, shipping, grandTotal } = computeTotal(p1, p2, settings);

  const lines = [
    'Hi Bluverse! I want to order the Buy 2 Pairs Offer.',
    '',
    `Pair 1: ${p1.name} (Size UK ${p1Size})${extra1 ? ` + Extra ₹${extra1}` : ''}`,
    `Pair 2: ${p2.name} (Size UK ${p2Size})${extra2 ? ` + Extra ₹${extra2}` : ''}`,
    '',
    `Base Price: ₹${base}`,
    `Extra Charge (Pair 1): ₹${extra1}`,
    `Extra Charge (Pair 2): ₹${extra2}`,
    `Shipping: ₹${shipping}`,
    `Grand Total: ₹${grandTotal}`,
    '',
    'Please confirm my order.'
  ];

  return lines.join('\n');
}

export function buildWhatsAppLink(number: string, message: string) {
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}
