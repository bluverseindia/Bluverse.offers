export type Product = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  category: string | null;
  extra_price: number;
  sizes: string[];
  images: string[];
  in_stock: boolean;
  created_at: string;
};

export type Settings = {
  id: number;
  base_price: number;
  shipping_charge: number;
  whatsapp_number: string;
};
