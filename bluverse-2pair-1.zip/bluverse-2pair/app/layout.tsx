import type { Metadata } from 'next';
import { Bebas_Neue, Inter } from 'next/font/google';
import './globals.css';

const display = Bebas_Neue({ subsets: ['latin'], weight: '400', variable: '--font-display' });
const body = Inter({ subsets: ['latin'], variable: '--font-body' });

export const metadata: Metadata = {
  title: 'Bluverse — Buy 2 Pairs Offer',
  description: 'Pick any two pairs. Premium sneakers, one unmissable offer. Order instantly on WhatsApp.',
  metadataBase: new URL('https://bluverse.example.com'),
  openGraph: {
    title: 'Bluverse — Buy 2 Pairs Offer',
    description: 'Pick any two pairs. Premium sneakers, one unmissable offer.',
    type: 'website'
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body className="font-body antialiased">{children}</body>
    </html>
  );
}
