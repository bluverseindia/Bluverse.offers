# Bluverse — Buy 2 Pairs Offer

Premium, mobile-first "Buy 2 Pairs" microsite. Customers pick two shoes, see a full price
breakdown, and order instantly on WhatsApp. Products are managed live through the Admin Panel —
no code changes needed to add, edit, or remove shoes.

Everything below is written for doing this entirely from your phone.

---

## 1. Create your Supabase project (the database)

1. Go to supabase.com → sign up/sign in → **New project**.
2. Pick any name/region, set a database password (save it somewhere), wait ~2 min for it to spin up.
3. In the project, go to **SQL Editor → New query**, paste the entire contents of
   `supabase/schema.sql` (in this project), and click **Run**. This creates the `products` and
   `settings` tables.
4. Go to **Authentication → Users → Add user**. Create yourself an admin login (your email +
   a strong password). This is the ONLY account that can log into `/admin`.
5. Go to **Project Settings → API**. You'll need three values for step 3 below:
   - **Project URL**
   - **anon public** key
   - **service_role** key (keep this secret — never share it)

## 2. Make your Google Sheet importable

Your sheet already has the right columns: `Shoe name`, `Extra price`, `size`, `image`, `image 2`.

1. Open the sheet → **Share** → change access to **"Anyone with the link" → Viewer**.
2. Note the Sheet ID from the URL — the long string between `/d/` and `/edit`. Yours is:
   `13VBFHzLj6QYsaqWhRcl46r4EQTAtG3dklAUN9rCNCbs`
3. Each Drive image link must also be shared as "Anyone with the link — Viewer", or it won't load
   on the site.

## 3. Push this project to GitHub

1. On GitHub (github.com/bluverseindia), create a new **empty** repository, e.g. `bluverse-2pair`.
2. Upload every file/folder from this project into it, keeping the folder structure exactly as-is
   (use GitHub's "Add file → Upload files" and drag in the whole extracted folder, or any file
   manager app that supports uploading a full directory to GitHub).
3. Do NOT upload `node_modules` or `.next` — they're excluded by `.gitignore` and aren't needed.

## 4. Deploy on Vercel

1. Go to vercel.com → **Add New → Project** → import the GitHub repo you just created.
2. Before deploying, open **Environment Variables** and add:

   | Key | Value |
   |---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | from Supabase step 1.5 |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | from Supabase step 1.5 |
   | `SUPABASE_SERVICE_ROLE_KEY` | from Supabase step 1.5 |
   | `GOOGLE_SHEET_ID` | `13VBFHzLj6QYsaqWhRcl46r4EQTAtG3dklAUN9rCNCbs` |

3. Click **Deploy**. In a couple minutes your site is live at a `vercel.app` URL.

## 5. Import your products

1. Visit `yoursite.vercel.app/admin/login` and sign in with the admin account you created.
2. Click **Run Import** under "Import from Google Sheet". This reads your sheet once and creates
   a product for every unique shoe (grouped by name + extra charge), pulling in all its images.
3. From here on, manage everything — add/edit/delete products, change prices, mark out of stock —
   directly from `/admin`. The Google Sheet is no longer used after this one-time import; new
   products go through the Admin Panel.
4. Set your **Base Price**, **Shipping**, and **WhatsApp number** at the top of the admin page —
   these apply to every order.

## 6. Point your Shopify "Buy 2 Pairs" banner here

Link the banner to your `vercel.app` URL (or a custom domain pointed at it via Vercel → Domains).

---

## How the flow works

Landing → Products (Pair 1) → Product detail + size → Products (Pair 2) → Product detail + size
→ Checkout (price breakdown) → WhatsApp order, pre-filled with both shoes, sizes, extra charges,
and grand total.

Pricing = **Base Price** (set in admin) + **Extra Charge Pair 1** + **Extra Charge Pair 2** +
**Shipping** (set in admin).

## Project structure

```
app/                    Pages (App Router)
  page.tsx              Landing page
  products/              Product listing (search + filters) and product detail + size select
  checkout/              Price breakdown + WhatsApp order button
  admin/                 Admin dashboard, login, product add/edit forms
  api/admin/             Server routes: create/update/delete products, settings, sheet import
components/             Reusable UI (header, product card, marquee)
lib/                    Supabase clients, pricing logic, types
supabase/schema.sql     Database schema — run once in Supabase SQL editor
```

## Local development (optional, needs a computer)

```
npm install
cp .env.example .env.local   # fill in your real values
npm run dev
```
