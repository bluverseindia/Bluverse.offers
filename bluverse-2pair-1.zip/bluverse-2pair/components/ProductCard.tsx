import Image from 'next/image';
import Link from 'next/link';
import { Product } from '@/lib/types';

export default function ProductCard({ product, href }: { product: Product; href: string }) {
  const outOfStock = !product.in_stock;
  const img = product.images?.[0];

  return (
    <Link
      href={outOfStock ? '#' : href}
      aria-disabled={outOfStock}
      className={`group relative block overflow-hidden rounded-3xl bg-bone transition ${
        outOfStock ? 'pointer-events-none opacity-50' : 'hover:-translate-y-1'
      }`}
    >
      <div className="relative aspect-square w-full overflow-hidden bg-white">
        {img ? (
          <Image
            src={img}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 50vw, 25vw"
            className="object-cover transition duration-700 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-smoke">No image</div>
        )}
        {outOfStock && (
          <span className="absolute left-3 top-3 rounded-full bg-ink px-3 py-1 text-[10px] font-semibold uppercase tracking-widest2 text-paper">
            Out of Stock
          </span>
        )}
        {!outOfStock && product.extra_price === 0 && (
          <span className="absolute left-3 top-3 rounded-full bg-ink px-3 py-1 text-[10px] font-semibold uppercase tracking-widest2 text-paper">
            No Extra Charge
          </span>
        )}
      </div>
      <div className="space-y-1 p-4">
        <h3 className="font-display text-xl leading-none tracking-wide">{product.name}</h3>
        <p className="text-xs uppercase tracking-widest2 text-smoke">
          {product.extra_price > 0 ? `+ ₹${product.extra_price} extra` : 'Included in base price'}
        </p>
      </div>
    </Link>
  );
}
