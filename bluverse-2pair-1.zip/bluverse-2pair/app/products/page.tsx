import Header from '@/components/Header';
import ProductGrid from './ProductGrid';
import { supabaseAdmin } from '@/lib/supabase-server';
import { Product } from '@/lib/types';

export const revalidate = 0;

export default async function ProductsPage({
  searchParams
}: {
  searchParams: { picking?: string; p1?: string; s1?: string };
}) {
  const supabase = supabaseAdmin();
  const { data } = await supabase
    .from('products')
    .select('*')
    .order('extra_price', { ascending: true })
    .order('name', { ascending: true });

  const products = (data ?? []) as Product[];
  const picking = searchParams.picking === '2' ? '2' : '1';

  return (
    <main className="min-h-screen bg-paper">
      <Header step={picking === '1' ? 'Step 1 — Select Pair 1' : 'Step 2 — Select Pair 2'} />
      <div className="mx-auto max-w-6xl px-5 py-10">
        <h1 className="font-display text-4xl tracking-wide sm:text-5xl">
          {picking === '1' ? 'Select Your First Pair' : 'Select Your Second Pair'}
        </h1>
        {picking === '2' && searchParams.p1 && (
          <p className="mt-2 text-sm text-smoke">
            Pair 1 selected. Now choose any pair to go with it — same shoe or something new.
          </p>
        )}
        <ProductGrid products={products} picking={picking} p1={searchParams.p1} s1={searchParams.s1} />
      </div>
    </main>
  );
}
